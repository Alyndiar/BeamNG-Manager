# Chrome BeamNG-Manager Bridge (MVP)

This extension shows `Subscribed` and `Manually Installed` highlights/badges on:

- `https://www.beamng.com/resources/*`
- `https://www.beamng.com/forums/*`

It uses the same localhost bridge as the Firefox extension:

- `GET http://127.0.0.1:<port>/installed-markers`

When BeamNG-Manager queues an open command, the extension reads `open_url_command` from the same payload and opens a new tab.

## Install (developer/unpacked)

1. Open Chrome `chrome://extensions`.
2. Enable `Developer mode`.
3. Click `Load unpacked`.
4. Select this folder.

## Port configuration

Set the same bridge port in both places:

- BeamNG-Manager: `Settings -> Browser Bridge Port`
- Extension popup/options: `Bridge port`

## Notes

- This is an MVP focused on BeamNG repo/forums pages.
- Communication is local-only over loopback.
