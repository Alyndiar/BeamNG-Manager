const extApi = typeof browser !== "undefined" ? browser : chrome;
const DEFAULT_PORT = 49441;

async function loadOptions() {
  const stored = await extApi.storage.local.get("bridgePort");
  const value = Number(stored.bridgePort || DEFAULT_PORT);
  const input = document.getElementById("bridgePort");
  input.value = Number.isInteger(value) ? value : DEFAULT_PORT;
}

async function saveOptions() {
  const input = document.getElementById("bridgePort");
  let value = Number(input.value || DEFAULT_PORT);
  if (!Number.isInteger(value)) {
    value = DEFAULT_PORT;
  }
  value = Math.max(1024, Math.min(65535, value));
  input.value = value;
  await extApi.storage.local.set({ bridgePort: value });
  const status = document.getElementById("status");
  status.textContent = `Saved port ${value}.`;
  window.setTimeout(() => {
    status.textContent = "";
  }, 1200);
}

document.getElementById("saveBtn").addEventListener("click", saveOptions);
loadOptions();
