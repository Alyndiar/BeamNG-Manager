const extApi = typeof browser !== "undefined" ? browser : chrome;
const DEFAULT_PORT = 49441;

async function loadPort() {
  const stored = await extApi.storage.local.get("bridgePort");
  const value = Number(stored.bridgePort || DEFAULT_PORT);
  const input = document.getElementById("bridgePort");
  input.value = Number.isInteger(value) ? value : DEFAULT_PORT;
}

async function savePort() {
  const input = document.getElementById("bridgePort");
  let value = Number(input.value || DEFAULT_PORT);
  if (!Number.isInteger(value)) {
    value = DEFAULT_PORT;
  }
  value = Math.max(1024, Math.min(65535, value));
  input.value = value;
  await extApi.storage.local.set({ bridgePort: value });
  const status = document.getElementById("status");
  status.textContent = `Saved port ${value}.`;
  setTimeout(() => {
    status.textContent = "";
  }, 1200);
}

async function openOptions() {
  if (extApi.runtime.openOptionsPage) {
    await extApi.runtime.openOptionsPage();
  }
}

document.getElementById("saveBtn").addEventListener("click", savePort);
document.getElementById("optionsBtn").addEventListener("click", openOptions);
loadPort();
