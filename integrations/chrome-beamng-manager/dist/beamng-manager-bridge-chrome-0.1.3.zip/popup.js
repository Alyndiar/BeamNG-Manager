const extApi = typeof browser !== "undefined" ? browser : chrome;
const DEFAULT_PORT = 49441;
const DEFAULT_POLL_SECONDS = 10;
const MIN_POLL_SECONDS = 4;
const MAX_POLL_SECONDS = 60;

function clampPollSeconds(value) {
  let seconds = Number(value || DEFAULT_POLL_SECONDS);
  if (!Number.isFinite(seconds)) {
    seconds = DEFAULT_POLL_SECONDS;
  }
  seconds = Math.round(seconds);
  return Math.max(MIN_POLL_SECONDS, Math.min(MAX_POLL_SECONDS, seconds));
}

async function loadPort() {
  const stored = await extApi.storage.local.get(["bridgePort", "bridgePollSeconds"]);
  const value = Number(stored.bridgePort || DEFAULT_PORT);
  const pollSeconds = clampPollSeconds(stored.bridgePollSeconds || DEFAULT_POLL_SECONDS);
  const input = document.getElementById("bridgePort");
  const pollInput = document.getElementById("bridgePollSeconds");
  input.value = Number.isInteger(value) ? value : DEFAULT_PORT;
  pollInput.value = pollSeconds;
}

async function savePort() {
  const input = document.getElementById("bridgePort");
  const pollInput = document.getElementById("bridgePollSeconds");
  let value = Number(input.value || DEFAULT_PORT);
  if (!Number.isInteger(value)) {
    value = DEFAULT_PORT;
  }
  value = Math.max(1024, Math.min(65535, value));
  const pollSeconds = clampPollSeconds(pollInput.value || DEFAULT_POLL_SECONDS);
  input.value = value;
  pollInput.value = pollSeconds;
  await extApi.storage.local.set({ bridgePort: value, bridgePollSeconds: pollSeconds });
  const status = document.getElementById("status");
  status.textContent = `Saved port ${value}; poll ${pollSeconds}s.`;
  setTimeout(() => {
    status.textContent = "";
  }, 1200);
}

async function openOptions() {
  if (extApi.runtime.openOptionsPage) {
    await extApi.runtime.openOptionsPage();
  }
}

document.getElementById("saveBtn").addEventListener("click", savePort);
document.getElementById("optionsBtn").addEventListener("click", openOptions);
loadPort();
