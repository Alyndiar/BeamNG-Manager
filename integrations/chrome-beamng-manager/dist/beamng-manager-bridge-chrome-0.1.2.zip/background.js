const extApi = typeof browser !== "undefined" ? browser : chrome;

const DEFAULT_PORT = 49441;
const PORT_SCAN_COUNT = 21;
const TAB_MATCH_PATTERNS = [
  "https://www.beamng.com/resources/*",
  "https://www.beamng.com/forums/*"
];
const POLL_ALARM_NAME = "beamng_manager_bridge_poll";
const POLL_PERIOD_MINUTES = 1;

let currentPort = null;
let currentPayload = null;
let online = false;
let lastOpenCommandId = null;
let lastBridgeSessionId = null;

function candidatePorts(basePort) {
  const out = [];
  const start = Number.isInteger(basePort) ? basePort : DEFAULT_PORT;
  for (let offset = 0; offset < PORT_SCAN_COUNT; offset += 1) {
    const port = start + offset;
    if (port >= 1024 && port <= 65535) {
      out.push(port);
    }
  }
  return out;
}

async function fetchMarkers(port) {
  const response = await fetch(`http://127.0.0.1:${port}/installed-markers`, { cache: "no-store" });
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }
  const payload = await response.json();
  if (!payload || payload.ok !== true) {
    throw new Error("Invalid payload");
  }
  return payload;
}

async function notifyTabs(message) {
  const tabs = await extApi.tabs.query({ url: TAB_MATCH_PATTERNS });
  await Promise.all(
    tabs.map((tab) => extApi.tabs.sendMessage(tab.id, message).catch(() => undefined))
  );
}

async function goOffline() {
  if (!online) {
    return;
  }
  online = false;
  currentPayload = null;
  currentPort = null;
  lastOpenCommandId = null;
  lastBridgeSessionId = null;
  await notifyTabs({ type: "beamng_manager_offline" });
}

function parseOpenUrlCommand(payload) {
  if (!payload || typeof payload !== "object") {
    return null;
  }
  const command = payload.open_url_command;
  if (!command || typeof command !== "object") {
    return null;
  }
  const id = Number(command.id);
  const url = String(command.url || "").trim();
  if (!Number.isFinite(id) || id <= 0 || !url) {
    return null;
  }
  if (!(url.startsWith("https://") || url.startsWith("http://"))) {
    return null;
  }
  return { id, url };
}

async function maybeOpenRequestedUrl(payload) {
  const command = parseOpenUrlCommand(payload);
  if (!command) {
    return;
  }
  if (Number.isFinite(lastOpenCommandId) && command.id <= Number(lastOpenCommandId)) {
    return;
  }
  lastOpenCommandId = command.id;
  try {
    await extApi.tabs.create({ url: command.url, active: true });
  } catch (_err) {
    // Ignore command failures; polling will continue.
  }
}

async function pushOnline(port, payload) {
  const nextPort = Number(port);
  const sessionId = String(payload && payload.bridge_session_id ? payload.bridge_session_id : "").trim() || null;
  if ((currentPort !== null && nextPort !== Number(currentPort)) || (sessionId && sessionId !== lastBridgeSessionId)) {
    lastOpenCommandId = null;
  }
  currentPort = nextPort;
  lastBridgeSessionId = sessionId;
  currentPayload = payload;
  online = true;
  await extApi.storage.local.set({ bridgePort: currentPort });
  await notifyTabs({ type: "beamng_manager_markers", payload });
  await maybeOpenRequestedUrl(payload);
}

async function pollBridge() {
  const stored = await extApi.storage.local.get("bridgePort");
  const preferred = Number(stored.bridgePort || DEFAULT_PORT);
  const ports = candidatePorts(preferred);

  for (const port of ports) {
    try {
      const payload = await fetchMarkers(port);
      await pushOnline(port, payload);
      return;
    } catch (_err) {
      // Continue scanning candidate ports.
    }
  }

  await goOffline();
}

function schedulePolling() {
  if (!extApi.alarms || !extApi.alarms.create) {
    return;
  }
  extApi.alarms.create(POLL_ALARM_NAME, { periodInMinutes: POLL_PERIOD_MINUTES });
}

extApi.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || message.type !== "beamng_manager_request_state") {
    return false;
  }
  (async () => {
    if (!online || !currentPayload) {
      await pollBridge();
    }
    if (online && currentPayload) {
      sendResponse({ type: "beamng_manager_markers", payload: currentPayload, port: currentPort });
      return;
    }
    sendResponse({ type: "beamng_manager_offline" });
  })();
  return true;
});

extApi.tabs.onUpdated.addListener((_tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab || !tab.id || !tab.url) {
    return;
  }
  if (!TAB_MATCH_PATTERNS.some((pattern) => tab.url.startsWith(pattern.replace("*", "")))) {
    return;
  }
  if (online && currentPayload) {
    extApi.tabs.sendMessage(tab.id, { type: "beamng_manager_markers", payload: currentPayload }).catch(() => undefined);
    return;
  }
  extApi.tabs.sendMessage(tab.id, { type: "beamng_manager_offline" }).catch(() => undefined);
});

if (extApi.alarms && extApi.alarms.onAlarm) {
  extApi.alarms.onAlarm.addListener((alarm) => {
    if (!alarm || alarm.name !== POLL_ALARM_NAME) {
      return;
    }
    pollBridge();
  });
}

if (extApi.runtime && extApi.runtime.onInstalled) {
  extApi.runtime.onInstalled.addListener(() => {
    schedulePolling();
    pollBridge();
  });
}

if (extApi.runtime && extApi.runtime.onStartup) {
  extApi.runtime.onStartup.addListener(() => {
    schedulePolling();
    pollBridge();
  });
}

schedulePolling();
pollBridge();
